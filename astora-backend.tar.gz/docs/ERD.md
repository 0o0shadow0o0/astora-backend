# Astora Backend ERD

## Entity Relationship Diagram

```
┌─────────────────┐
│     USERS       │
├─────────────────┤
│ id (PK)         │
│ email            │
│ name             │
│ phone            │
│ username         │
│ password         │
│ avatar           │
│ is_active        │
│ is_verified      │
│ two_factor_*     │
│ manager_id (FK)  │
│ created_at       │
│ updated_at       │
└────────┬─────────┘
         │
         │ 1:N
         ▼
┌─────────────────┐      ┌─────────────────┐
│    DEVICES      │      │    SESSIONS     │
├─────────────────┤      ├─────────────────┤
│ id (PK)         │      │ id (PK)         │
│ user_id (FK)    │      │ user_id (FK)    │
│ name            │      │ device_id (FK)  │
│ ip_address      │      │ refresh_token   │
│ user_agent      │      │ status          │
│ type            │      │ expires_at      │
│ status          │      └─────────────────┘
└─────────────────┘
         │
         │
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                    WHATSAPP_ACCOUNTS                            │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ user_id (FK)                                                    │
│ name, provider, status, phone_number                            │
│ business_name, profile_*                                         │
│ multi_device, auto_reconnect, sync_*                            │
│ reconnect_interval, max_reconnect_attempts                       │
│ session_data, qr_code, qr_expires_at                            │
│ last_connected_at, last_disconnected_at                         │
│ error_message                                                   │
└────────┬────────────────────────────────────────────────────────┘
         │
         │ 1:N
         ▼
┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│    CONTACTS     │      │  CHAT_THREADS   │      │   CAMPAIGNS     │
├─────────────────┤      ├─────────────────┤      ├─────────────────┤
│ id (PK)         │      │ id (PK)         │      │ id (PK)         │
│ whatsapp_acc_*  │◄─────│ whatsapp_acc_*  │      │ user_id (FK)    │
│ phone           │      │ contact_id (FK)│      │ whatsapp_acc_*  │
│ name            │      │ external_id     │      │ name, type      │
│ profile_*       │      │ type           │      │ status, message│
│ business_*     │      │ status, title   │      │ media_url       │
│ email, address  │      │ unread_count    │      │ scheduled_at    │
│ company, about  │      │ message_count   │      │ *_count         │
│ type            │      │ last_message    │      └─────────────────┘
│ is_blocked      │      └────────┬────────┘
│ is_muted        │               │
│ is_starred      │               │ 1:N
└─────────────────┘               ▼
                          ┌─────────────────┐
                          │    MESSAGES     │
                          ├─────────────────┤
                          │ id (PK)         │
                          │ chat_thread_*   │
                          │ user_id (FK)    │
                          │ external_id     │
                          │ type, status    │
                          │ direction       │
                          │ content         │
                          │ media_*         │
                          │ is_deleted      │
                          │ is_edited       │
                          │ reply_to_id     │
                          └─────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                       SCHEDULED_TASKS                          │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ user_id (FK)                                                    │
│ name, type, status, priority                                    │
│ cron_expression, scheduled_at                                    │
│ started_at, completed_at                                         │
│ max_retries, retry_count, timeout_seconds                        │
│ payload (JSONB)                                                  │
│ error_message, is_recurring, recurring_end_date                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      AUTOMATION_FLOWS                            │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ user_id (FK)                                                    │
│ name, description, status                                        │
│ trigger (JSONB), actions (JSONB), conditions (JSONB)            │
│ executions_count, success_count, failure_count                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────┐
│    PRODUCTS     │
├─────────────────┤
│ id (PK)         │
│ user_id (FK)    │
│ category_id(FK) │
│ name, sku       │
│ price           │
│ sale_price      │
│ stock_quantity  │
│ images          │
│ is_active       │
│ attributes      │
│ tags            │
└────────┬────────┘
         │
         │ 1:N
         ▼
┌─────────────────┐      ┌─────────────────┐
│   CATEGORIES    │      │     ORDERS      │
├─────────────────┤      ├─────────────────┤
│ id (PK)         │      │ id (PK)         │
│ user_id (FK)    │      │ user_id (FK)    │
│ parent_id (FK)  │      │ customer_id(FK) │
│ name, slug      │      │ order_number    │
│ description     │      │ status          │
│ image           │      │ payment_status  │
│ sort_order      │      │ subtotal, total │
│ is_active       │      │ shipping_*      │
└─────────────────┘      │ shipped_at      │
                        │ delivered_at    │
                        └────────┬────────┘
                                 │ 1:N
                                 ▼
                         ┌─────────────────┐
                         │   ORDER_ITEMS   │
                         ├─────────────────┤
                         │ id (PK)         │
                         │ order_id (FK)   │
                         │ quantity        │
                         │ unit_price      │
                         │ total           │
                         │ sku             │
                         │ product_name    │
                         └─────────────────┘

┌─────────────────┐      ┌─────────────────┐
│    CUSTOMERS   │      │     COUPONS     │
├─────────────────┤      ├─────────────────┤
│ id (PK)         │      │ id (PK)         │
│ user_id (FK)    │      │ user_id (FK)    │
│ name            │      │ code            │
│ email           │      │ type, value     │
│ phone           │      │ min_order_amount│
│ type            │      │ max_discount    │
│ company         │      │ usage_limit     │
│ address         │      │ used_count      │
│ total_spent     │      │ starts_at       │
│ order_count     │      │ expires_at      │
│ points          │      │ is_active       │
│ is_vip          │      │ applicable_*    │
└─────────────────┘      └─────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                     AI_CONVERSATIONS                             │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ user_id (FK)                                                    │
│ title, provider                                                 │
│ status, context (JSONB)                                         │
│ message_count                                                   │
│ contact_phone, chat_thread_id                                   │
└────────┬────────────────────────────────────────────────────────┘
         │
         │ 1:N
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                       AI_MESSAGES                               │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ conversation_id (FK)                                            │
│ content                                                         │
│ role                                                            │
│ tokens, metadata (JSONB)                                        │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────┐      ┌─────────────────┐      ┌─────────────────┐
│ NOTIFICATIONS   │      │      LOGS       │      │   AUDIT_LOGS    │
├─────────────────┤      ├─────────────────┤      ├─────────────────┤
│ id (PK)         │      │ id (PK)         │      │ id (PK)         │
│ user_id (FK)     │      │ level           │      │ action          │
│ title, message  │      │ message         │      │ entity_type     │
│ type            │      │ context         │      │ entity_id       │
│ channels        │      │ logger          │      │ old_values      │
│ status          │      │ metadata (JSON) │      │ new_values      │
│ is_read         │      │ user_id (FK)    │      │ ip_address      │
│ reference_id    │      └─────────────────┘      │ user_agent      │
│ data (JSONB)    │                               │ user_id (FK)    │
└─────────────────┘                               │ session_id      │
                                                  │ metadata (JSON) │
┌─────────────────────────────────────────────────┴─────────────────┐
│                          ROLES                                   │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ name, slug, description                                         │
│ type, is_active, is_system                                      │
└────────┬────────────────────────────────────────────────────────┘
         │
         │ N:M
         ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PERMISSIONS                                 │
├─────────────────────────────────────────────────────────────────┤
│ id (PK)                                                         │
│ name, slug                                                      │
│ resource, action                                                │
│ description, is_active                                          │
└─────────────────────────────────────────────────────────────────┘
```

## Key Relationships

1. **Users** have many **Devices**, **Sessions**, **WhatsApp Accounts**
2. **WhatsApp Accounts** have many **Contacts**, **Chat Threads**, **Campaigns**
3. **Chat Threads** have many **Messages**
4. **Scheduled Tasks** and **Automation Flows** belong to Users
5. **Products** belong to **Categories** and Users
6. **Orders** have many **Order Items** and belong to **Customers**
7. **AI Conversations** have many **AI Messages**
8. **Roles** have many **Permissions** (N:M)
9. **Users** have many **Roles** (N:M)
